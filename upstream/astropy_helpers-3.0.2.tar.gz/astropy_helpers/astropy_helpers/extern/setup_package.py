# Licensed under a 3-clause BSD style license - see LICENSE.rst

def get_package_data():
    return {'astropy_helpers.extern': ['automodapi/templates/*/*.rst', 'numpydoc/templates/*.rst']}
